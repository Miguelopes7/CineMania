<?php
    //config.php

    $base_dados = "cinemania"; // nome da base de dados
    $host = "localhost"; // localização
    $user = "root"; // user para aceder á base de dados. Xamp default: root
    $password = ""; // password para aceder á base de dados. Xamp default: sem password
?>