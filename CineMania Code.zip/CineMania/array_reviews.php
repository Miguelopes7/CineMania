<?php

$imagens_reviews = array(
    array("Matrix","capas/matrix_capa.webp", "Uma realidade virtual que desafia todas as noções da existência humana.<br>Quote: A Matrix está em todo o lado, está à nossa volta, até agora mesmo neste quarto. Podes vê-la quando olhas pela janela ou quando ligas a televisão.<br>Podes senti-la quando vais para o trabalho, quando vais à igreja, quando pagas os teus impostos. É o mundo que te foi posto à frente dos olhos para te cegar da verdade.", "fig-review", "Matrix"),
    array("John Wick","capas/john-wick_capa.webp", "Um implacável assassino de aluguel em busca de vingança após a morte do seu cão e o roubo do seu carro, enfrentando inimigos perigosos e revelando suas habilidades letais.<br>Quote: Eu já o vi matar três homens em um bar... com um lápis. Com um maldito lápis!", "fig-review", "JohnWick"),
    array("Dia de Treinamento<br>Training Day","capas/trainingday_capa.webp", "Um intenso thriller policial que segue um dia na vida de um detetive veterano e corrupto que leva um recruta idealista para uma jornada perigosa pelas ruas de Los Angeles.<br>Quote: King Kong ain't got shit on me!", "fig-review", "TrainingDay")

    //template: array("Nome","capas/_capa.webp", "Descrição.<br>Quote: ", "fig-nome"),
);
?>