<?php
	include "header.php";
	include "trailers.php";
	include "top12.php";
	include "noticias.php";
	include "footer.php";
?>